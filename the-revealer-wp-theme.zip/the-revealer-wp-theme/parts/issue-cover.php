<?php
global $issue;
$title = $issue->name;
$slug = $issue->slug;
$id = $issue->term_id;
$issue_url = get_term_link( $id, 'issues' );
$date = get_field( 'date', $issue );
$thumb = get_field( 'featured_image', $issue );
$special = get_field( 'special', $issue );
$special_title = get_field( 'special_title', $issue );
echo '<div class="col ' . ( $col_size ? $col_size : 'col-12') . ' issue" role="issue">';
	if( $special ) {
		echo '<div class="label special">Special Issue</div>';
	}
	echo !isset( $no_link ) ? '<a class="link_wrap" href="' . $issue_url . '">' : '<div class="link_wrap">';
		echo '<div class="text">';
			echo '<hgroup>';
				echo '<h2 class="title">' . $title . '</h2>';
				if( $special && $special_title ) {
					echo '<div class="subtitle">' . $special_title . '</div>';
				}
			echo '</hgroup>';
			echo '<div class="date">' . $date . '</div>';
		echo '</div>';
		if( $thumb ) {
			$thumb_id = $thumb['ID'];
			$thumb = wp_get_attachment_image_src( $thumb_id, 'large' );
			$thumb_url = $thumb[0];
			$thumb_width = $thumb[1];
			$thumb_height = $thumb[2];
			echo '<div class="image load">';
				echo '<img data-src="'.$thumb_url.'" data-width="'.$thumb_width.'" data-height="'.$thumb_height.'"/>';
			echo '</div>';
		}
	echo !isset( $no_link ) ? '</a>' : '</div>';
	// $mag_svg = get_template_directory_uri() . '/assets/images/mag.svg';
	// echo file_get_contents( $mag_svg );
echo '</div>';
?>