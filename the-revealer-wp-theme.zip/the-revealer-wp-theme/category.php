<?php
/*
Template Name: Category
*/
get_header();
$cat_param = $_GET['category'];
if( $cat_id = get_query_var( 'cat' ) ) {
	$cat_param = get_category( $cat_id, false )->slug;
}
$year_param = $_GET['y'];
$column_param = $_GET['column'];
// $paged = $_GET['page'];
$paged = get_query_var( 'paged' );
if( !$paged ) {
	$paged = 1;
}
$articles_args = array(
	'post_type' => 'post',
	'paged' => $paged,
	'posts_per_page' => 25
);


$tax_query = array();
if( $cat_param && sizeof( $cat_param ) ) {
	$articles_args['category_name'] = $cat_param;
}
if( $year_param && sizeof( $year_param ) ) {
	$articles_args['year'] = $year_param;
}
if( $column_param && sizeof( $column_param ) ) {
	$tax_query[] = array(
		'taxonomy' => 'columns',
		'field' => 'slug',
	  'terms' => $column_param,
  );
}

if( $tax_query && sizeof( $tax_query ) ) {
	$articles_args['tax_query'] = $tax_query;
}

query_posts( $articles_args );
echo '<div class="readable">';
	echo '<div class="loop articles medium masonry">';
		if ( $wp_query->have_posts() ) {
			while ( $wp_query->have_posts() ) {
				the_post();
				get_template_part( 'parts/article' );
			}
		} else {
			echo '<div id="empty">';
				echo 'Sorry, this are no articles.';
			echo '</div>';
		}
	echo '</div>';
echo '</div>';
get_template_part( 'parts/pagination' );
wp_reset_query();
get_footer();
?>